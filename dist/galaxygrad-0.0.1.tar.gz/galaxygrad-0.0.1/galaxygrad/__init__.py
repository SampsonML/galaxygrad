from .scorenet import ScoreNet32, ScoreNet64
